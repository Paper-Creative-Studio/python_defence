exec()
a=5
b=6
wynik = addition(a, b)
if a + b == addition(a, b):
	print("Returned value is addition result of two arguments")
else:
	print("Returned value is not addition result of two arguments")